# Creating a string
str1 = 'Hello, World!'

# Searching for a substring
try:
    index = str1.index('World')
    print("The substring 'World' is found at index", index)
except ValueError:
    print("The substring 'World' is not found in the string")

# Searching for another substring
try:
    index = str1.index('Universe')
    print("The substring 'Universe' is found at index", index)
except ValueError:
    print("The substring 'Universe' is not found in the string")