def divide_numbers(a, b):
    try:
        result = a / b
        print(f"The result of {a} / {b} is {result}")
    except ZeroDivisionError:
        print("Error: Cannot divide by zero!")
    finally:
        print("Finally block executed!")

# Test the function
divide_numbers(10, 2)
divide_numbers(10, 0)