def is_less_than(a, b):
    if a - b < 0:
        return True
    else:
        return False

def is_less_than_or_equal_to(a, b):
    if a - b <= 0:
        return True
    else:
        return False

def is_greater_than(a, b):
    if a - b > 0:
        return True
    else:
        return False

def is_greater_than_or_equal_to(a, b):
    if a - b >= 0:
        return True
    else:
        return False
num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
print("Is", num1, "<", num2, ":", is_less_than(num1, num2))
print("Is", num1, "<==", num2, ":", is_less_than_or_equal_to(num1, num2))
print("Is", num1, ">", num2, ":", is_greater_than(num1, num2))
print("Is", num1, ">==10", num2, ":", is_greater_than_or_equal_to(num1, num2))