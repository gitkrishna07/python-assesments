class ClassTwo:
    def __init__(self, number):
        self.number = number

    def square(self):
        return self.number ** 2