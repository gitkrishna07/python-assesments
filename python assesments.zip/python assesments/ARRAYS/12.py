def remove_duplicates(arr):
    return list(set(arr))
numbers = [1, 2, 2, 3, 4, 4, 4, 5, 6, 6]
unique_numbers = remove_duplicates(numbers)
print(unique_numbers)