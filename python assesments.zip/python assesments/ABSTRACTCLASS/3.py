from abc import ABC, abstractmethod

# Abstract class
class AbstractClassExample(ABC):
    # Abstract method
    @abstractmethod
    def abstract_method(self):
        pass

    # Abstract method with parameters
    @abstractmethod
    def abstract_method_with_params(self, param1, param2):
        pass

# Concrete class that inherits from the abstract class
class ConcreteClass(AbstractClassExample):
    # Implementing the abstract method
    def abstract_method(self):
        print("Implementing the abstract method in the concrete class")

    # Implementing the abstract method with parameters
    def abstract_method_with_params(self, param1, param2):
        print(f"Implementing the abstract method with params: {param1}, {param2} in the concrete class")

    def create_instance_and_call_abstract_methods(self):
        # Creating an instance of the concrete class inside the concrete class
        instance = ConcreteClass()

        # Calling the abstract method through the instance
        print("Calling abstract method through the instance:")
        instance.abstract_method()

        # Calling the abstract method with parameters through the instance
        print("Calling abstract method with params through the instance:")
        instance.abstract_method_with_params("Hello", "World")

# Creating an instance of the concrete class
concrete_instance = ConcreteClass()

# Calling the method to create an instance and call abstract methods
concrete_instance.create_instance_and_call_abstract_methods()