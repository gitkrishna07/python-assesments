def insert_element(arr, element, position):
    if position < 0 or position > len(arr):
        raise IndexError("Position out of range")
    arr.insert(position, element)
    return arr
numbers = [1, 2, 3, 4, 5]
element = 10
position = 2
result = insert_element(numbers, element, position)
print(result)