from abc import ABC, abstractmethod

# Abstract class
class AbstractClassExample(ABC):
    # Non-abstract method
    def non_abstract_method(self):
        print("This is a non-abstract method in the abstract class")

    # Non-abstract method with parameters
    def non_abstract_method_with_params(self, param1, param2):
        print(f"Non-abstract method with params: {param1}, {param2} in the abstract class")

    # Abstract method
    @abstractmethod
    def abstract_method(self):
        pass

# Concrete class that inherits from the abstract class
class ConcreteClass(AbstractClassExample):
    # Implementing the abstract method
    def abstract_method(self):
        print("Implementing the abstract method in the concrete class")

    def create_instance_and_call_non_abstract_methods(self):
        # Creating an instance of the concrete class inside the concrete class
        instance = ConcreteClass()

        # Calling the non-abstract method through the instance
        print("Calling non-abstract method through the instance:")
        instance.non_abstract_method()

        # Calling the non-abstract method with parameters through the instance
        print("Calling non-abstract method with params through the instance:")
        instance.non_abstract_method_with_params("Hello", "World")

# Creating an instance of the concrete class
concrete_instance = ConcreteClass()

# Calling the method to create an instance and call non-abstract methods
concrete_instance.create_instance_and_call_non_abstract_methods()