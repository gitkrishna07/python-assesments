def find_duplicates(arr):
    return [value for value in set(arr) if arr.count(value) > 1]
numbers = [1, 2, 2, 3, 4, 4, 4, 5, 6, 6]
duplicates = find_duplicates(numbers)
print(duplicates)