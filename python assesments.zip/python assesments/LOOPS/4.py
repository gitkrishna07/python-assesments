def is_even(n):
    if n % 2 == 0:
        return True
    else:
        return False

def is_odd(n):
    if n % 2!= 0:
        return True
    else:
        return False

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

print("Even numbers:")
for num in numbers:
    if is_even(num):
        print(num)

print("\nOdd numbers:")
for num in numbers:
    if is_odd(num):
        print(num)