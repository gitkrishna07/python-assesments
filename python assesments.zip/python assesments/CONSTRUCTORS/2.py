# Define the superclass with multiple constructors
class SuperClass:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        print(f"SuperClass constructor called with x={x} and y={y}")

    def __str__(self):
        return f"SuperClass(x={self.x}, y={self.y})"

# Define the child class that calls the superclass constructors
class ChildClass(SuperClass):
    def __init__(self, x=0, y=0, z=0):
        # Call the default constructor of the superclass
        if x == 0 and y == 0:
            super().__init__()
        # Call the one argument constructor of the superclass
        elif y == 0:
            super().__init__(x)
        # Call the two argument constructor of the superclass
        else:
            super().__init__(x, y)
        self.z = z
        print(f"ChildClass constructor called with z={z}")

    def __str__(self):
        return f"ChildClass(x={self.x}, y={self.y}, z={self.z})"

# Create instances of the child class to call the superclass constructors
child1 = ChildClass()
print(child1)

child2 = ChildClass(10)
print(child2)

child3 = ChildClass(20, 30)
print(child3)

child4 = ChildClass(40, 50, 60)
print(child4)