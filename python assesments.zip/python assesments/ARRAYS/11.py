def find_common_values(arr1, arr2):
    return list(set(arr1) & set(arr2))

def main():
    arr1 = input("Enter the first array (separated by space): ").split()
    arr2 = input("Enter the second array (separated by space): ").split()
    arr1 = [int(x) for x in arr1]
    arr2 = [int(x) for x in arr2]
    common_values = find_common_values(arr1, arr2)
    print("Common values:", common_values)

if __name__ == "__main__":
    main()