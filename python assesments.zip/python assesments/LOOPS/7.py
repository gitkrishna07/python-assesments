num = 1
while True:
    print(num)
    num += 1
    if num > 10:
        break