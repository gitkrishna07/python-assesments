def difference_largest_smallest(arr):
    return max(arr) - min(arr)
numbers = [ 5, 7, 3, 1, 9, 2, 4, 6]
difference = difference_largest_smallest(numbers)
print(f"Difference between largest and smallest values: {difference}")