class MyClass:
    my_static_variable = "This is a static variable"

    def __init__(self):
        pass

    def access_static_variable(self):
        return MyClass.my_static_variable
my_instance = MyClass()
print(my_instance.access_static_variable())
print(my_instance.my_static_variable)