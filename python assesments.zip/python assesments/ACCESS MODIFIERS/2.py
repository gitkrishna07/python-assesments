# mypackage/myclass.py
class MyClass:
    def __init__(self):
        self._protected_field1 = "Protected field 1"
        self._protected_field2 = "Protected field 2"

    def _protected_method(self):
        print("This is a protected method")

# mypackage/myotherclass.py
from .myclass import MyClass

class MyOtherClass:
    def access_protected(self, obj):
        print("Accessing protected fields and method from same package:")
        print(obj._protected_field1)
        print(obj._protected_field2)
        obj._protected_method()

# Create objects and test access
obj = MyClass()
my_other_obj = MyOtherClass()
my_other_obj.access_protected(obj)