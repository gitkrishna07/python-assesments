# Define a class with a constructor that takes attributes
class Car:
    def __init__(self, brand, model, year, color, mileage=0):
        self.brand = brand  # public attribute
        self._model = model  # protected attribute
        self.__year = year  # private attribute
        self.color = color  # public attribute
        self.mileage = mileage  # public attribute

    def display_info(self):
        print(f"Brand: {self.brand}")
        print(f"Model: {self._model}")
        print(f"Year: {self.__year}")
        print(f"Color: {self.color}")
        print(f"Mileage: {self.mileage} miles")

# Create an instance of the Car class
my_car = Car("Toyota", "Corolla", 2020, "Silver")

# Access and modify public attributes
print("Initial attributes:")
my_car.display_info()
my_car.color = "Black"
my_car.mileage = 5000
print("\nUpdated attributes:")
my_car.display_info()

# Try to access protected attribute
try:
    print(my_car._model)
except AttributeError:
    print("Error: Cannot access protected attribute from outside the class")

# Try to access private attribute
try:
    print(my_car.__year)
except AttributeError:
    print("Error: Cannot access private attribute from outside the class")

# Use name mangling to access private attribute
print(f"Private year attribute: {my_car._Car__year}")