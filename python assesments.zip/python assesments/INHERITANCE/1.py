# Class A (super class)
class A:
    def method_a1(self):
        print("Method A1 specific to class A")

    def method_a2(self):
        print("Method A2 specific to class A")

    def override_method(self):
        print("Override method in class A")

# Class B (sub class of A)
class B(A):
    def method_b1(self):
        print("Method B1 specific to class B")

    def method_b2(self):
        print("Method B2 specific to class B")

    def override_method(self):
        print("Override method in class B")

# Class C (sub class of B)
class C(B):
    def method_c1(self):
        print("Method C1 specific to class C")

    def method_c2(self):
        print("Method C2 specific to class C")

    def override_method(self):
        print("Override method in class C")

# Create objects of each class
a = A()
b = B()
c = C()

# Call methods on each object
print("Class A:")
a.method_a1()
a.method_a2()
a.override_method()

print("\nClass B:")
b.method_b1()
b.method_b2()
b.override_method()

print("\nClass C:")
c.method_c1()
c.method_c2()
c.override_method()