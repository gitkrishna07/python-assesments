# Creating a string
str1 = 'Hello, Sai Krishna'

# Finding and printing the length of the string in a single line
print("The length of the string is:", len(str1))