class MyClass:
    my_static_variable = "Initial value"

    def __init__(self):
        pass

    def change_static_variable(self, new_value):
        MyClass.my_static_variable = new_value
my_instance1 = MyClass()
print(MyClass.my_static_variable)
my_instance1.change_static_variable("New value")
print(MyClass.my_static_variable)
my_instance2 = MyClass()
print(my_instance2.my_static_variable)