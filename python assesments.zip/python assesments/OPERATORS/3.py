def are_equal(a, b):
    if a == b:
        return True
    else:
        return False
num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
result = are_equal(num1, num2)
if result:
    print("The two numbers are equal.")
else:
    print("The two numbers are not equal.")