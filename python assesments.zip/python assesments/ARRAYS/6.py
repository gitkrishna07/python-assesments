def copy_array(arr):
    return arr.copy()
numbers = [1, 2, 3, 4, 5]
copied_numbers = copy_array(numbers)
print(copied_numbers)