# This class accesses public fields and methods from PublicAccessClass in the same package.
from public_access_class import PublicAccessClass

def main():
    public_access_class = PublicAccessClass()

    # Accessing public fields
    public_access_class.public_field1 = 10
    public_access_class.public_field2 = "Hello"

    # Accessing public methods
    public_access_class.public_method1()
    print(public_access_class.public_method2())

if __name__ == "__main__":
    main()