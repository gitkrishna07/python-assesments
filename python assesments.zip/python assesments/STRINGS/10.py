# Defining a string
str1 = 'Hello, World!'

# Using replace() to replace a character
str1_replaced = str1.replace('Hello', 'Hi')
print("str1_replaced:", str1_replaced)

# Defining a string with multiple occurrences of a character
str2 = 'banana'

# Using replace() to replace all occurrences of a character
str2_replaced = str2.replace('ba', 'ga')
print("str2_replaced:", str2_replaced)

# Defining a string with multiple occurrences of a substring
str3 = 'Hello, Hello, Hello!'

# Using replace() to replace all occurrences of a substring
str3_replaced = str3.replace('Hello', 'Goodbye')
print("str3_replaced:", str3_replaced)

# Defining a string with multiple occurrences of a character
str4 = 'banana'

# Using replace() to replace a limited number of occurrences of a character
str4_replaced = str4.replace('a', 'x', 2)
print("str4_replaced:", str4_replaced)

# Defining a string with uppercase and lowercase characters
str5 = 'Hello, World!'

# Using replace() to replace characters in a case-insensitive manner
str5_replaced = str5.replace('h', 'j').replace('H', 'J')
print("str5_replaced:", str5_replaced)