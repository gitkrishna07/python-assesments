from abc import ABC, abstractmethod

# Abstract class
class AbstractClassExample(ABC):
    # Abstract method
    @abstractmethod
    def abstract_method(self):
        pass

    # Non-abstract method
    def non_abstract_method(self):
        print("This is a non-abstract method")

    # Abstract method with parameters
    @abstractmethod
    def abstract_method_with_params(self, param1, param2):
        pass

    # Non-abstract method with parameters
    def non_abstract_method_with_params(self, param1, param2):
        print(f"Non-abstract method with params: {param1}, {param2}")

# Concrete class that inherits from the abstract class
class ConcreteClass(AbstractClassExample):
    # Implementing the abstract method
    def abstract_method(self):
        print("Implementing the abstract method")

    # Implementing the abstract method with parameters
    def abstract_method_with_params(self, param1, param2):
        print(f"Implementing the abstract method with params: {param1}, {param2}")

# Creating an instance of the concrete class
concrete_instance = ConcreteClass()

# Calling the abstract method
concrete_instance.abstract_method()

# Calling the non-abstract method
concrete_instance.non_abstract_method()

# Calling the abstract method with parameters
concrete_instance.abstract_method_with_params("Hello", "World")

# Calling the non-abstract method with parameters
concrete_instance.non_abstract_method_with_params("Python", "Programming")