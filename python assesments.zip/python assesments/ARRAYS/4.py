def contains_value(arr, target):
    return target in arr
numbers = [1, 2, 3, 4, 5]
target = 3
result = contains_value(numbers, target)

if result:
    print(f"Array contains {target}.")
else:
    print(f"Array does not contain {target}.")