# Define the class with multiple constructors
class MyClass:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        print(f"Constructor called with x={x} and y={y}")

    def __str__(self):
        return f"MyClass(x={self.x}, y={self.y})"

# Define the main class
class Main:
    def main(self):
        # Instantiate the class with default constructor
        obj1 = MyClass()
        print(obj1)

        # Instantiate the class with one argument constructor
        obj2 = MyClass(10)
        print(obj2)

        # Instantiate the class with two argument constructor
        obj3 = MyClass(20, 30)
        print(obj3)

# Create an instance of the main class and call the main method
main = Main()
main.main()