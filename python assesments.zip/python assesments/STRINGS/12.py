# Defining an integer object
num1 = 10

# Converting the integer object to a string
str1 = str(num1)
print("str1:", str1)
print("Type of str1:", type(str1))

# Defining another integer object
num2 = 20

# Converting the integer object to a string using the format() method
str2 = "{}".format(num2)
print("str2:", str2)
print("Type of str2:", type(str2))

# Defining another integer object
num3 = 30

# Converting the integer object to a string using f-strings (Python 3.6+)
str3 = f"{num3}"
print("str3:", str3)
print("Type of str3:", type(str3))

# Defining a list of integer objects
numbers = [40, 50, 60]

# Converting the list of integer objects to a string
str4 = ", ".join(map(str, numbers))
print("str4:", str4)
print("Type of str4:", type(str4))