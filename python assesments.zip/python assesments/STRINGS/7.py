# Defining two strings
str1 = 'Hello, World!'
str2 = 'Hello, World!'
str3 = 'hello, world!'

# Comparing strings using ==
if str1 == str2:
    print("str1 and str2 are equal")
else:
    print("str1 and str2 are not equal")

if str1 == str3:
    print("str1 and str3 are equal")
else:
    print("str1 and str3 are not equal")

# Comparing strings using !=
if str1 != str2:
    print("str1 and str2 are not equal")
else:
    print("str1 and str2 are equal")

if str1 != str3:
    print("str1 and str3 are not equal")
else:
    print("str1 and str3 are equal")

# Comparing strings using case-insensitive comparison
if str1.casefold() == str3.casefold():
    print("str1 and str3 are equal (case-insensitive)")
else:
    print("str1 and str3 are not equal (case-insensitive)")

# Comparing strings using <
if str1 < str2:
    print("str1 is less than str2")
else:
    print("str1 is not less than str2")

if str1 < str3:
    print("str1 is less than str3")
else:
    print("str1 is not less than str3")

# Comparing strings using >
if str1 > str2:
    print("str1 is greater than str2")
else:
    print("str1 is not greater than str2")

if str1 > str3:
    print("str1 is greater than str3")
else:
    print("str1 is not greater than str3")