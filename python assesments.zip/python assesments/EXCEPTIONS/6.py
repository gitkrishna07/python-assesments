# Define a custom exception class
class InsufficientBalanceException(Exception):
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount
        message = f"Insufficient balance sai krishna! You have ${balance} but need ${amount} to complete the transaction."
        super().__init__(message)

# Define a class that uses the custom exception
class BankAccount:
    def __init__(self, balance=0):
        self.balance = balance

    def withdraw(self, amount):
        if amount > self.balance:
            raise InsufficientBalanceException(self.balance, amount)
        else:
            self.balance -= amount
            print(f"Withdrew ${amount}. New balance: ${self.balance}")

# Create a bank account and try to withdraw more than the balance
account = BankAccount(100)
try:
    account.withdraw(150)
except InsufficientBalanceException as e:
    print(e)