def remove_duplicates(arr):
    return list(set(arr))
numbers = [10, 5, 7, 3, 1, 9, 8, 2, 4, 6, 10, 5, 7, 3, 1]
new_array = remove_duplicates(numbers)
print(f"New array with duplicates removed: {new_array}")