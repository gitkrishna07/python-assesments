# Define a function that divides two numbers
def divide_numbers(x: int, y: int) -> float:
    try:
        # Attempt to divide x by y
        result = x / y
        return result
    except ZeroDivisionError:
        # Catch the ArithmeticException and print an error message
        print("Error: Cannot divide by zero!")
        return None

# Call the function with a divisor of 0
result = divide_numbers(10, 0)

if result is not None:
    print(f"Result: {result}")