from abc import ABC, abstractmethod

# Abstract class
class AbstractClassExample(ABC):
    # Abstract method
    @abstractmethod
    def abstract_method(self):
        pass

    # Non-abstract method
    def non_abstract_method(self):
        print("This is a non-abstract method in the abstract class")

    # Non-abstract method with parameters
    def non_abstract_method_with_params(self, param1, param2):
        print(f"Non-abstract method with params: {param1}, {param2} in the abstract class")

# Concrete class that inherits from the abstract class
class ConcreteClass(AbstractClassExample):
    # Implementing the abstract method
    def abstract_method(self):
        print("Implementing the abstract method in the concrete class")

    def create_abstract_class_object(self):
        # Creating an object of the abstract class is not possible directly
        # But we can create an object of the concrete class and access the non-abstract methods
        # of the abstract class through it
        abstract_class_object = self

        # Accessing the non-abstract method
        print("Accessing non-abstract method through the object:")
        abstract_class_object.non_abstract_method()

        # Accessing the non-abstract method with parameters
        print("Accessing non-abstract method with params through the object:")
        abstract_class_object.non_abstract_method_with_params("Hello", "World")

# Creating an instance of the concrete class
concrete_instance = ConcreteClass()

# Calling the method to create an object and access non-abstract methods
concrete_instance.create_abstract_class_object()