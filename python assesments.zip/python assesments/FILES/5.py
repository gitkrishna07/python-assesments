def read_file_up_to_index(file_name, index):
    try:
        # Open the file in binary read mode
        with open(file_name, "rb") as file:
            # Seek to the specified index
            file.seek(index)

            # Read the rest of the file from the current position
            remaining_data = file.read()

            # Print the data read
            print(f"Data read up to index {index}: {remaining_data.decode('utf-8')}")

    except IOError as e:
        print(f"Error reading file: {e}")

# Example usage:
file_name = "example.txt"
index = 20  # Read up to the 20th byte
read_file_up_to_index(file_name, index)