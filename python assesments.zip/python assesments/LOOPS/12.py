#Python does not have a built-in switch statement like some other languages.
def print_gender(gender):
    if gender.upper() == "M":
        return "male"
    elif gender.upper() == "F":
        return "female"
    else:
        return "Invalid input"
input_gender = input("Enter a gender (M/F): ")
print(print_gender(input_gender))