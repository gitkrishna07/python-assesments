#Python does not have a built-in switch statement like some other languages.
def check_even_odd(n):
    return {
        n % 2 == 0: "EVEN",
        n % 2!= 0: "ODD"
    }.get(True, "Invalid input")
num = int(input("Enter a number: "))
print(check_even_odd(num))