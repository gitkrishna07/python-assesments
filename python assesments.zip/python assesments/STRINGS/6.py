import re

# Creating a string
str1 = 'Hello, World!'

# Defining a regular expression pattern
pattern = r'^Hello'

# Matching the string against the pattern
match = re.match(pattern, str1)

# Checking if the pattern matches the string
if match:
    print("The string matches the pattern")
    print("Matched text:", match.group())
else:
    print("The string does not match the pattern")

# Defining another regular expression pattern
pattern = r'^Universe'

# Matching the string against the pattern
match = re.match(pattern, str1)

# Checking if the pattern matches the string
if match:
    print("The string matches the pattern")
    print("Matched text:", match.group())
else:
    print("The string does not match the pattern")