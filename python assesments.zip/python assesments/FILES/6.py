import os

def check_file_permissions(file_name):
    try:
        # Check if the file exists
        if not os.path.exists(file_name):
            print(f"File '{file_name}' does not exist.")
            return

        # Check read access
        if os.access(file_name, os.R_OK):
            print(f"File '{file_name}' has read access.")
        else:
            print(f"File '{file_name}' does not have read access.")

        # Check write access
        if os.access(file_name, os.W_OK):
            print(f"File '{file_name}' has write access.")
        else:
            print(f"File '{file_name}' does not have write access.")

    except Exception as e:
        print(f"Error checking file permissions: {e}")

# Example usage:
file_name = "example.txt"
check_file_permissions(file_name)