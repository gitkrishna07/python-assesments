try:
    # Try to open a file that does not exist
    with open("non_existent_file.txt", "r") as file:
        print("File contents:", file.read())
except FileNotFoundError as e:
    print("File not found error occurred:", e)