# Define a function that divides two numbers
def divide_numbers(x: int, y: int) -> float:
    return x / y

# Call the function with a divisor of 0
result = divide_numbers(10, 0)

print(f"Result: {result}")