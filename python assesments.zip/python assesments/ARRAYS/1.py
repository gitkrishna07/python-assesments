def sum_array_manual(arr):
   #This function calculates the sum of all integers in a given array manually.
    total = 0
    for num in arr:
        total += num
    return total
numbers = [1, 2, 3, 4, 5]
result = sum_array_manual(numbers)
print(result)