def find_min_max(arr):
    if not arr:
        raise ValueError("Array is empty")
    return min(arr), max(arr)
numbers = [1, 2, 3, 4, 5]
min_value, max_value = find_min_max(numbers)
print(f"Minimum value: {min_value}, Maximum value: {max_value}")