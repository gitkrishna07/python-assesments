custom_equal = lambda a, b: a - b == 0
custom_not_equal = lambda a, b: a - b!= 0

a = 5
b = 5
c = 10

# Equal operator (==)
if custom_equal(a, b):
    print("a and b are equal")
else:
    print("a and b are not equal")

# Not equal operator (!=)
if custom_not_equal(a, c):
    print("a and c are not equal")
else:
    print("a and c are equal")