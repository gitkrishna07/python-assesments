def remove_element(arr, target):
    if target in arr:
        arr.remove(target)
    return arr
numbers = [1, 2, 3, 4, 5]
target = 3
result = remove_element(numbers, target)
print(result) 