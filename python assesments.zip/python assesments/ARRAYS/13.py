def second_largest(arr):
    if len(arr) < 2:
        return None
    largest = second_largest = float('-inf')
    for num in arr:
        if num > largest:
            second_largest = largest
            largest = num
        elif num > second_largest and num != largest:
            second_largest = num
    if second_largest == float('-inf'):
        return None
    return second_largest
numbers = [12, 13, 1, 10, 34, 16]
second_largest_num = second_largest(numbers)
print(second_largest_num)