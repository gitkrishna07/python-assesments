# Defining a string with spaces as separators
str1 = 'Hello World Python Programming'

# Using split() to split a string into a list of words
words = str1.split()
print("Words:", words)

# Defining a string with commas as separators
str2 = 'apple,banana,cherry,orange'

# Using split() to split a string into a list of fruits
fruits = str2.split(',')
print("Fruits:", fruits)

# Defining a string with tabs as separators
str3 = 'apple\tbanana\tcherry\torange'

# Using split() to split a string into a list of fruits
fruits = str3.split('\t')
print("Fruits:", fruits)

# Defining a string with multiple spaces as separators
str4 = 'Hello   World   Python   Programming'

# Using split() to split a string into a list of words
words = str4.split()
print("Words:", words)

# Defining a string with a specific separator
str5 = 'apple|banana|cherry|orange'

# Using split() to split a string into a list of fruits
fruits = str5.split('|')
print("Fruits:", fruits)

# Defining a string with a maximum number of splits
str6 = 'apple,banana,cherry,orange,grape,mango'

# Using split() to split a string into a list of fruits with a maximum number of splits
fruits = str6.split(',', 3)
print("Fruits:", fruits)