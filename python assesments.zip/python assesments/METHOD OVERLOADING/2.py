# Define a class with a method that can take a variable number of parameters of different data types
class Calculator:
    def calculate(self, *args) -> str:
        if len(args) == 2 and all(isinstance(x, int) for x in args):
            return str(sum(args))
        elif len(args) == 2 and all(isinstance(x, str) for x in args):
            return ''.join(args)
        else:
            return "Error: Invalid parameters"

# Create an instance of the Calculator class
calc = Calculator()

# Call the method with different number of parameters of different data types
result1 = calc.calculate(10, 20)
print(f"Result with 2 integer parameters: {result1}")

result2 = calc.calculate("Hello, ", "World!")
print(f"Result with 2 string parameters: {result2}")