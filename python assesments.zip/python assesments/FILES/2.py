def write_to_file(file_name, text):
    try:
        # Open the file in write mode
        with open(file_name, "w") as file:
            # Write the text to the file
            file.write(text)
        print(f"Text written to {file_name} successfully!")
    except IOError as e:
        print(f"Error writing to file: {e}")

# Example usage:
file_name = "example.txt"
text = "This is an example text to be written to a file."
write_to_file(file_name, text)