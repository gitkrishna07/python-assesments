def generate_arithmetic_exception():
    try:
        # Divide by zero, which will raise a ZeroDivisionError
        result = 10 / 0
        print("Result:", result)
    except ArithmeticError as e:
        print("Arithmetic Exception occurred:", e)

generate_arithmetic_exception()