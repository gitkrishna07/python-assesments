# Open the file in read mode
with open("C:/Users/YELOORI deepika/OneDrive/Desktop/python assesments/FILES/3explaination.txt", "r") as file:
    # Read the entire file
    content = file.read()

    # Print the content
    print(content)