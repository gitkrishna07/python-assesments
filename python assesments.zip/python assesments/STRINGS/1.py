# 1. Using Quotes
str1 = 'Hello, World!'
str2 = "Hello, World!"
print("Using Quotes:")
print(str1)
print(str2)

# 2. Using Triple Quotes
str1 = '''This is a multiline string.
It can span multiple lines.'''
str2 = """This is also a multiline string.
It can also span multiple lines."""
print("\nUsing Triple Quotes:")
print(str1)
print(str2)

# 3. Using the str Function
num = 10
str1 = str(num)
print("\nUsing the str Function:")
print(str1)

# 4. Using String Literals
str1 = r'C:\Windows'  # raw string literal
str2 = u'Hello, World!'  # unicode string literal
str3 = b'Hello, World!'  # byte string literal
print("\nUsing String Literals:")
print(str1)
print(str2)
print(str3)

# 5. Using the format Method
name = 'Sai Krishna'
age = 22
str1 = 'My name is {} and I am {} years old.'.format(name, age)
print("\nUsing the format Method:")
print(str1)

# 6. Using F-Strings
name = 'Sai Krishna'
age = 22
str1 = f'My name is {name} and I am {age} years old.'
print("\nUsing F-Strings:")
print(str1)

# 7. Using the join Method
words = ['Hello', 'World', 'Python']
str1 = ' '.join(words)
print("\nUsing the join Method:")
print(str1)

# 8. Using the + Operator
str1 = 'Hello, ' + 'World!'
print("\nUsing the + Operator:")
print(str1)

# 9. Using the % Operator
name = 'Sai Krishna'
age = 22
str1 = 'My name is %s and I am %d years old.' % (name, age)
print("\nUsing the % Operator:")
print(str1)

# 10. Using Template Strings
from string import Template
name = 'Sai Krishna'
age = 22
str1 = Template('My name is $name and I am $age years old.').substitute(name=name, age=age)
print("\nUsing Template Strings:")
print(str1)