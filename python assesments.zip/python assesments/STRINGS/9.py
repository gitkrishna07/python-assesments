a="  hi  "
print(a.strip())#removes starting and ending or default spaces
b="ahi"
print(b.lstrip("a"))#removes left side character
c="hia"
print(c.rstrip("a"))#removes right side character
