# Define a class with a method that can take a variable number of parameters
class Calculator:
    def add(self, x: int, y: int = 0, z: int = 0) -> int:
        return x + y + z

# Create an instance of the Calculator class
calc = Calculator()

# Call the method with different number of parameters
result1 = calc.add(10)
print(f"Result with 1 parameter: {result1}")

result2 = calc.add(10, 20)
print(f"Result with 2 parameters: {result2}")

result3 = calc.add(10, 20, 30)
print(f"Result with 3 parameters: {result3}")