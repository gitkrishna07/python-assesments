# 1. Create a Dictionary with at least 5 key value pairs of the Student ID and Name
student_dict = {
    101: "sai krishna",
    102: "rohith",
    103: "sana",
    104: "Aliya",
    105: "harsh"
}

print("Initial Dictionary:")
print(student_dict)

# 1.1. Adding the values in dictionary
student_dict[106] = "hari"
print("\nAfter adding a new student:")
print(student_dict)

# 1.2. Updating the values in dictionary
student_dict[102] = "sai krishna"
print("\nAfter updating a student's name:")
print(student_dict)

# 1.3. Accessing the value in dictionary
print("\nAccessing a student's name:")
print(student_dict[103]) 

# 1.4. Create a nested loop dictionary
nested_dict = {
    101: {"name": "sai krishna", "grade": "A"},
    102: {"name": "rohith", "grade": "B"},
    103: {"name": "sana", "grade": "A"},
    104: {"name": "Aliya", "grade": "C"},
    105: {"name": "harsh", "grade": "B"}
}

print("\nNested Dictionary:")
print(nested_dict)

# 1.5. Access the values of nested loop dictionary
print("\nAccessing a student's grade:")
print(nested_dict[102]["grade"]) 

# 1.6. Print the keys present in a particular dictionary
print("\nKeys in the dictionary:")
print(list(student_dict.keys()))

# 1.7. Delete a value from a dictionary
del student_dict[104]
print("\nAfter deleting a student:")
print(student_dict)