# Define a class with a method that throws a custom exception
class CustomException(Exception):
    pass

class ExceptionThrower:
    def throw_exception(self, name):
        if name == "":
            raise CustomException("name cannot be empty it should be sai krishna")
        else:
            print(f"Hello, {name}!")

# Define a main class that calls the method and catches the custom exception
class Main:
    def main(self):
        exception_thrower = ExceptionThrower()
        try:
            exception_thrower.throw_exception("")
        except CustomException as e:
            print(f"Error: {e}")

# Create an instance of the main class and call the main method
main = Main()
main.main()