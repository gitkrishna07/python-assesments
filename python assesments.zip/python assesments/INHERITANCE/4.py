# Class A (super class)
class A:
    def __init__(self):
        self.a = "A's data member"

    def display(self):
        print("Data member in class A:", self.a)

# Class B (sub class of A)
class B(A):
    def __init__(self):
        super().__init__()  # Calls A's constructor
        self.b = "B's data member"

    def display(self):
        super().display()  # Calls A's display method
        print("Data member in class B:", self.b)

# Class C (sub class of B)
class C(B):
    def __init__(self):
        super().__init__()  # Calls B's constructor
        self.c = "C's data member"

    def display(self):
        super().display()  # Calls B's display method
        print("Data member in class C:", self.c)

# Main class
class Main:
    def main(self):
        # Create objects of each class
        a = A()
        b = B()
        c = C()

        # Call display method on each object
        print("Class A:")
        a.display()

        print("\nClass B:")
        b.display()

        print("\nClass C:")
        c.display()

        # Runtime polymorphism with data members
        print("\nRuntime polymorphism with data members:")
        a_ref = A()
        b_ref = A()  # Reference of superclass A to object of subclass B
        c_ref = A()  # Reference of superclass A to object of subclass C

        b_obj = B()
        c_obj = C()

        b_ref = b_obj
        c_ref = c_obj

        b_ref.display()  # Calls display method in class B
        c_ref.display()  # Calls display method in class C

# Create an object of Main class and call main method
main = Main()
main.main()