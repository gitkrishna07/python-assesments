# Importing the classes from the package
from myproject import ClassOne, ClassTwo

def main():
    # Create an object of ClassOne
    obj_one = ClassOne("Alice")
    print(obj_one.greet())
    
    # Create an object of ClassTwo
    obj_two = ClassTwo(4)
    print(f"The square of {obj_two.number} is {obj_two.square()}")

if __name__ == "__main__":
    main()