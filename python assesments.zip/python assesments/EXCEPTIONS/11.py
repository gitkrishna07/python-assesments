#In Python, there is no direct equivalent to Java's IOException. However, we can simulate a similar behavior by trying to perform an I/O operation that fails.

#Here's an example of a Python program that generates an IOError, which is similar to an IOException:
try:
    # Try to open a file in a directory that does not exist
    with open("/non/existent/directory/file.txt", "w") as file:
        file.write("Hello, world!")
except IOError as e:
    print("IO error occurred:", e)