class Counting:
    def __init__(self, value=0):
        self.value = value

    def __iadd__(self, increment):
        self.value += increment
        return self

    def __isub__(self, decrement):
        self.value -= decrement
        return self

    def __str__(self):
        return str(self.value)

counting = Counting(5)
print("Initial value:", counting)  
# Increment operator (++)
counting += 2
print("After increment:", counting)
# Decrement operator (--)
counting -= 1
print("After decrement:", counting)