# Define the superclass with multiple constructors and access modifiers
class SuperClass:
    def __init__(self, x=0, y=0):  # default constructor
        self.__private_x = x  # private attribute
        self._protected_y = y  # protected attribute
        self.public_z = 0  # public attribute
        print(f"SuperClass default constructor called with x={x} and y={y}")

    def __private_init(self, x, y):  # private constructor
        self.__private_x = x
        self._protected_y = y
        print(f"SuperClass private constructor called with x={x} and y={y}")

    def _protected_init(self, x, y):  # protected constructor
        self.__private_x = x
        self._protected_y = y
        print(f"SuperClass protected constructor called with x={x} and y={y}")

    def public_init(self, x, y):  # public constructor
        self.__private_x = x
        self._protected_y = y
        print(f"SuperClass public constructor called with x={x} and y={y}")

# Define the child class that calls the superclass constructors
class ChildClass(SuperClass):
    def __init__(self, x=0, y=0, z=0):  # default constructor
        super().__init__(x, y)
        self.public_z = z
        print(f"ChildClass constructor called with z={z}")

    def __private_child_init(self, x, y, z):  # private constructor
        super()._SuperClass__private_init(x, y)  # call private constructor of superclass
        self.public_z = z
        print(f"ChildClass private constructor called with z={z}")

    def _protected_child_init(self, x, y, z):  # protected constructor
        super()._protected_init(x, y)  # call protected constructor of superclass
        self.public_z = z
        print(f"ChildClass protected constructor called with z={z}")

    def public_child_init(self, x, y, z):  # public constructor
        super().public_init(x, y)  # call public constructor of superclass
        self.public_z = z
        print(f"ChildClass public constructor called with z={z}")

# Create instances of the child class to call the superclass constructors
child1 = ChildClass()
print(child1)

child2 = ChildClass(10)
print(child2)

child3 = ChildClass(20, 30)
print(child3)

child4 = ChildClass(40, 50, 60)
print(child4)

# Try to access private constructor from outside the class
try:
    child5 = ChildClass.__private_child_init(70, 80, 90)
except AttributeError:
    print("Error: Cannot access private constructor from outside the class")

# Try to access protected constructor from outside the class
try:
    child6 = ChildClass._protected_child_init(100, 110, 120)
except AttributeError:
    print("Error: Cannot access protected constructor from outside the class")