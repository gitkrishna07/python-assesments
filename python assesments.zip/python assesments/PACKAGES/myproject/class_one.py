class ClassOne:
    def __init__(self, name):
        self.name = name

    def greet(self):
        return f"Hello from ClassOne, {self.name}!"