def index(arr, target):
    try:
        return arr.index(target)
    except ValueError:
        return -1
numbers = [1, 2, 3, 4, 5]
target = 3
result = index(numbers, target)

if result != -1:
    print(f"Element {target} found at index {result}.")
else:
    print(f"Element {target} not found in the array.")