# Global variable
x = 100
def my_function():
    # Local variable 
    x = 200
    print("Local variable x:", x)
print("Global variable x:", x)
my_function()
print("Global variable x after function call:", x)