# package1/__init__.py
from. import module1
from. import module2