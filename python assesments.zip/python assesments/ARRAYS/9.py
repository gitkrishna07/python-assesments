def reverse_array(arr):
    if not arr:
        raise ValueError("Array is empty")
    return arr[::-1]
numbers = [1, 2, 3, 4, 5]
reversed_numbers = reverse_array(numbers)
print(reversed_numbers)