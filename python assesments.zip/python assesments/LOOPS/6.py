num = 10
while num <= 20:
    if num % 2 == 0:
        print(num)
    num += 1