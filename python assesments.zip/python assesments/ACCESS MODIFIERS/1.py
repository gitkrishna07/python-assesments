# Class with private fields and method
class MyClass:
    def __init__(self):
        self.__private_field1 = "Private field 1"
        self.__private_field2 = "Private field 2"

    def __private_method(self):
        print("This is a private method")

    def main_method(self):
        print("Private fields:")
        print(self.__private_field1)
        print(self.__private_field2)
        self.__private_method()

# Subclass that tries to access private fields and method
class MySubClass(MyClass):
    def try_to_access_private(self):
        try:
            print("Trying to access private field 1:", self.__private_field1)
        except AttributeError:
            print("Error: Cannot access private field 1")

        try:
            print("Trying to access private field 2:", self.__private_field2)
        except AttributeError:
            print("Error: Cannot access private field 2")

        try:
            self.__private_method()
        except AttributeError:
            print("Error: Cannot access private method")

# Create an object of MyClass and call main_method
obj = MyClass()
obj.main_method()

# Create an object of MySubClass and try to access private fields and method
sub_obj = MySubClass()
sub_obj.try_to_access_private()