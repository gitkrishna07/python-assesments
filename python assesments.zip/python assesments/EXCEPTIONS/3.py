# Define a class with a method that throws an exception
class ExceptionThrower:
    def throw_exception(self):
        raise RuntimeError("This is a runtime error!")

# Define a main class that calls the method without a try block
class Main:
    def main(self):
        exception_thrower = ExceptionThrower()
        exception_thrower.throw_exception()

# Create an instance of the main class and call the main method
main = Main()
main.main()