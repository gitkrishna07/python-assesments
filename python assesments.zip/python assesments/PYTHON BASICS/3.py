# Integer variable
int_var = 100
print("Integer variable:", int_var)
print("Type of int_var:", type(int_var))

# Boolean variable
bool_var = True
print("\nBoolean variable:", bool_var)
print("Type of bool_var:", type(bool_var))

# Character variable as Python does not have a separate character data type, it is treated as a string of length 1
char_var = 'SAI'
print("\nCharacter variable:", char_var)
print("Type of char_var:", type(char_var))

# Float variable
float_var = 100.5
print("\nFloat variable:", float_var)
print("Type of float_var:", type(float_var))

# Double variable as Python does not have a separate double data type, it is treated as a float
double_var = 10.123456789
print("\nDouble variable:", double_var)
print("Type of double_var:", type(double_var))

# Complex variable
complex_var = 100 + 5j
print("\nComplex variable:", complex_var)
print("Type of complex_var:", type(complex_var))