def arithmetic_operation(num1, num2, operator):
    if operator == '+':
        return num1 + num2
    elif operator == '-':
        return num1 - num2
    elif operator == '*':
        return num1 * num2
    elif operator == '/':
        if num2 == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return num1 / num2
    else:
        raise ValueError("Invalid operator. Only '+', '-', '*', '/' are allowed.")
print(arithmetic_operation(100, 10, '+')) 
print(arithmetic_operation(1000, 20, '-'))  
print(arithmetic_operation(10, 2, '*'))  
print(arithmetic_operation(20, 2, '/'))  
try:
    print(arithmetic_operation(10, 0, '/'))
except ZeroDivisionError as e:
    print(e)

try:
    print(arithmetic_operation(10, 2, '%'))
except ValueError as e:
    print(e)