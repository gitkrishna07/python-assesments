def average_array(arr):
    return sum(arr) / len(arr)
numbers = [1, 2, 3, 4, 5, 6]
result = average_array(numbers)
print(result)