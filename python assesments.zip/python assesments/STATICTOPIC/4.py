class MyClass:
    my_static_variable = "Initial value"

    my_static_variable = "New value"
print(MyClass.my_static_variable)