# Defining a string in lowercase
str1 = 'hello world'

# Converting the string to uppercase
str1_upper = str1.upper()
print("str1_upper:", str1_upper)

# Defining a string in uppercase
str2 = 'HELLO WORLD'

# Converting the string to lowercase
str2_lower = str2.lower()
print("str2_lower:", str2_lower)

# Defining a string with mixed case
str3 = 'HeLlO WoRlD'

# Converting the string to uppercase
str3_upper = str3.upper()
print("str3_upper:", str3_upper)

# Converting the string to lowercase
str3_lower = str3.lower()
print("str3_lower:", str3_lower)

# Defining a string with mixed case
str4 = 'hElLo wOrLd'

# Converting the string to title case (first letter of each word capitalized)
str4_title = str4.title()
print("str4_title:", str4_title)

# Defining a string with mixed case
str5 = 'hElLo wOrLd'

# Converting the string to swap case (uppercase becomes lowercase and vice versa)
str5_swap = str5.swapcase()
print("str5_swap:", str5_swap)