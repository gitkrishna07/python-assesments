# This class demonstrates public fields and methods.
class PublicAccessClass:
    # Public fields
    public_field1 = None
    public_field2 = None

    # Public methods
    def public_method1(self):
        print("Public Method 1")

    def public_method2(self):
        return "Public Method 2"