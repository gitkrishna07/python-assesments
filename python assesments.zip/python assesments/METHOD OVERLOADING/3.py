# Define a class with a method that can perform different operations based on an instance variable
class Calculator:
    def __init__(self, is_addition=True):
        self.is_addition = is_addition

    def calculate(self, x: int, y: int) -> int:
        if self.is_addition:
            return x + y
        else:
            return x - y

# Create an instance of the Calculator class for addition
calc_add = Calculator(is_addition=True)

# Call the method for addition
result_add = calc_add.calculate(10, 20)
print(f"Result of addition: {result_add}")

# Create an instance of the Calculator class for subtraction
calc_subtract = Calculator(is_addition=False)

# Call the method for subtraction
result_subtract = calc_subtract.calculate(20, 10)
print(f"Result of subtraction: {result_subtract}")