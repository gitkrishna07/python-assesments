# Defining a string
str1 = 'Hello, World!'

# Using startswith()
if str1.startswith('Hello'):
    print("str1 starts with 'Hello'")
else:
    print("str1 does not start with 'Hello'")

if str1.startswith('hello'):
    print("str1 starts with 'hello'")
else:
    print("str1 does not start with 'hello'")

# Using endswith()
if str1.endswith('World!'):
    print("str1 ends with 'World!'")
else:
    print("str1 does not end with 'World!'")

if str1.endswith('world!'):
    print("str1 ends with 'world!'")
else:
    print("str1 does not end with 'world!'")

# Using case-insensitive startswith() and endswith()
if str1.casefold().startswith('hello'.casefold()):
    print("str1 starts with 'hello' (case-insensitive)")
else:
    print("str1 does not start with 'hello' (case-insensitive)")

if str1.casefold().endswith('world!'.casefold()):
    print("str1 ends with 'world!' (case-insensitive)")
else:
    print("str1 does not end with 'world!' (case-insensitive)")

# Comparing strings using ==
if str1 == 'Hello, World!':
    print("str1 is equal to 'Hello, World!'")
else:
    print("str1 is not equal to 'Hello, World!'")

if str1 == 'hello, world!':
    print("str1 is equal to 'hello, world!'")
else:
    print("str1 is not equal to 'hello, world!'")

# Comparing strings using!=
if str1!= 'Hello, World!':
    print("str1 is not equal to 'Hello, World!'")
else:
    print("str1 is equal to 'Hello, World!'")

if str1!= 'hello, world!':
    print("str1 is not equal to 'hello, world!'")
else:
    print("str1 is equal to 'hello, world!'")

# Comparing strings using <
if str1 < 'Hello, World!':
    print("str1 is less than 'Hello, World!'")
else:
    print("str1 is not less than 'Hello, World!'")

if str1 < 'hello, world!':
    print("str1 is less than 'hello, world!'")
else:
    print("str1 is not less than 'hello, world!'")

# Comparing strings using >
if str1 > 'Hello, World!':
    print("str1 is greater than 'Hello, World!'")
else:
    print("str1 is not greater than 'Hello, World!'")

if str1 > 'hello, world!':
    print("str1 is greater than 'hello, world!'")
else:
    print("str1 is not greater than 'hello, world!'")