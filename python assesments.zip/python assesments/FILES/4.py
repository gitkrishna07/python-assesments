def read_file_random_access(file_name):
    try:
        # Open the file in binary read mode
        with open(file_name, "rb") as file:
            # Get the file size
            file_size = file.seek(0, 2)
            file.seek(0)  # Reset the file pointer to the beginning

            # Read the file in chunks of 10 bytes
            chunk_size = 10
            while True:
                chunk = file.read(chunk_size)
                if not chunk:
                    break
                print(f"Read chunk: {chunk.decode('utf-8')}")

            # Seek to a specific position in the file (e.g. 20 bytes from the beginning)
            file.seek(20)
            print(f"Seeked to position 20, read: {file.read(10).decode('utf-8')}")

            # Seek to the end of the file
            file.seek(file_size - 10)
            print(f"Seeked to end of file, read: {file.read(10).decode('utf-8')}")

    except IOError as e:
        print(f"Error reading file: {e}")

# Example usage:
file_name = "example.txt"
read_file_random_access(file_name)