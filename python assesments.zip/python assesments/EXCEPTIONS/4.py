# Define a class with a method that throws different types of exceptions
class ExceptionThrower:
    def throw_exception(self, type):
        if type == "runtime":
            raise RuntimeError("This is a runtime error!")
        elif type == "value":
            raise ValueError("This is a value error!")
        elif type == "type":
            raise TypeError("This is a type error!")
        else:
            raise Exception("This is a generic exception!")

# Define a main class that calls the method with multiple catch blocks
class Main:
    def main(self):
        exception_thrower = ExceptionThrower()
        try:
            exception_thrower.throw_exception("runtime")
        except RuntimeError as e:
            print(f"Caught RuntimeError: {e}")
        except ValueError as e:
            print(f"Caught ValueError: {e}")
        except TypeError as e:
            print(f"Caught TypeError: {e}")
        except Exception as e:
            print(f"Caught generic Exception: {e}")

# Create an instance of the main class and call the main method
main = Main()
main.main()