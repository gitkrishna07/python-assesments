# package3/__init__.py
from. import module5
from. import module6