class MyClass:

#This class demonstrates the use of a static variable.

    my_static_variable = "This is a static variable"

    def __init__(self):
        pass

    @staticmethod
    def access_static_variable():
        return MyClass.my_static_variable
print(MyClass.my_static_variable)
print(MyClass.access_static_variable())
my_instance = MyClass()
print(my_instance.my_static_variable)
