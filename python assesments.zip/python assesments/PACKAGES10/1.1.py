# Abstract class
class AbstractClassExample:
    def __init__(self, name):
        self.name = name

    def abstract_class_method(self):
        print(f"This is a method in the abstract class: {self.name}")

    def abstract_method(self):
        raise NotImplementedError("Subclasses must implement this method")

# Concrete class that inherits from the abstract class
class ConcreteClass(AbstractClassExample):
    def __init__(self, name, age):
        super().__init__(name)
        self.age = age

    def abstract_method(self):
        print(f"This is the implementation of the abstract method in the concrete class: {self.name}, {self.age}")

    def concrete_class_method(self):
        print(f"This is a method in the concrete class: {self.name}, {self.age}")

# Creating an instance of the concrete class
concrete_instance = ConcreteClass("Sai Krishna", 22)

# Calling the methods
concrete_instance.abstract_class_method()
concrete_instance.abstract_method()
concrete_instance.concrete_class_method()