# we use'#' for single line comment
print("hi good morning") # this is a program ofsingle line comment

'''
This is a multi-line comment
that spans multiple lines
'''

print("hi sai krishna good morning")

"""
This is another multi-line comment
that also represents multiple lines
"""