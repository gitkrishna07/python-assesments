def contains_elements(arr, elem1, elem2):
    return elem1 in arr and elem2 in arr
numbers1 = [10, 5, 7, 3, 9, 8, 2, 4, 6, 12, 23]
result = contains_elements(numbers1, 12, 23)
print(f"Array contains 12 and 23: {result}")
numbers2 = [10, 5, 7, 3, 1, 9, 8, 2, 4, 6]
result = contains_elements(numbers2, 12, 23)
print(f"Array contains 12 and 23: {result}")