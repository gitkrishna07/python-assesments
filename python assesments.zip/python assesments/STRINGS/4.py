# Creating a string
str1 = 'Hello, Krishna'

# Extracting a substring
substr1 = str1[0:5]  # Extracting the first 5 characters
substr2 = str1[7:]  # Extracting from the 8th character to the end
substr3 = str1[0:10:2]  # Extracting every 2nd character from the start to the 10th character

# Printing the substrings
print("Original String:", str1)
print("Substring 1:", substr1)
print("Substring 2:", substr2)
print("Substring 3:", substr3)