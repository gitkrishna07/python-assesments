# package2/__init__.py
from. import module3
from. import module4