# myproject/__init__.py
from .class_one import ClassOne
from .class_two import ClassTwo