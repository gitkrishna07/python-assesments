num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

smaller = num1 if num1 - num2 < 0 else num2
larger = num1 if num1 - num2 >= 0 else num2

print("Smaller number:", smaller)
print("Larger number:", larger)